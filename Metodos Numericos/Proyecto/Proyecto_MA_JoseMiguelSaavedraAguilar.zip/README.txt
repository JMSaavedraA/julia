Solución numérica del problema de Sitnikov
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora. Genera gráfica de theta, r y z.

Además, podemos correr

julia mainGIF.jl

que en vez de las gráficas, genera un GIF de la animación