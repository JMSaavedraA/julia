Problema 3 del examen
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se puede cambiar m (en el examen m=5000) en main.jl. Se utilizan los algoritmos de potencia, potencia inversa y de iteración en subespacios para aproximar los eigenvalores.

Se guardan los eigenvalores en lambdaMetodo.txt y sus correspondientes eigenvectores en PhiMetodo.txt, donde "Metodo" puede ser "Potencia", "Iteracion", "Inversa" o "IteracionInversa"