Problema 1 del examen
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se puede cambiar m (en el examen m=5000) en main.jl.

La solución de Ax=b se guarda en xExamen.txt