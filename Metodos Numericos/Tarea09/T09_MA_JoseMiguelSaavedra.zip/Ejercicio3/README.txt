Ejercicio 3 de la tarea
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se puede cambiar la semilla pues los puntos son aleatorios.

Se guarda la gráfica como "pSplineCubico1-m.png" y cada una de las interpolaciones como p1-m.txt donde m es el número de puntos que se consideran.