Ejercicio 4 de la tarea
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se puede cambiar la semilla pues los puntos son aleatorios.

Se guarda la gráfica como "comparacion-m.png" y cada una de las interpolaciones como pMetodo-m.txt donde m es el número de puntos que se consideran y Metodo es el método utilizado.