Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora, o desde Visual Studio Code, igualmente con la carpeta contenedora

Se incluye el valor de x obtenido con cada algoritmo para evitar la necesidad de correrlo, pero es posible correrlo, en general toma aproximadamente 8 minutos para A.txt, b.txt,
excepto la eliminación Gaussiana, que toma aproximadamente 30 minutos.