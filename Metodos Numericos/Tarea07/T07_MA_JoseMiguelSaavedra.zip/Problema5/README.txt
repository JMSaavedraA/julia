Ejercicio 5 de la tarea
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se puede cambiar qué problema se resuelve (3 o 125) directamente en el main.jl y se incluyen los obtenidos para ambos problemas.

El archivo resultante se guarda como xCGm.txt donde m es el tamaño que estamos resolviendo