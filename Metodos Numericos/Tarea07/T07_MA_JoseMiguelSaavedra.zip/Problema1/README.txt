Ejercicio 1 de la tarea
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se puede cambiar qué problema se resuelve (3 o 50) directamente en el main.jl y se incluyen los obtenidos para ambos problemas.

Los archivos resultantes se guardan como PhiIteracionm.txt y lambdaIteracionm.txt donde m es el tamaño que estamos resolviendo