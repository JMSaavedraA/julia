Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora, o desde Visual Studio Code, igualmente con la carpeta contenedora

Se puede cambiar el valor del coeficiente para la perturbación de la primera función