Ejercicio 4 de la tarea
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se imprime el valor de la integral y del error de aproximación directamente en pantalla.