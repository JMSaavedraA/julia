Ejercicio 3 de la tarea
Para correr esta tarea se requiere que las librerias Plots y LaTeXStrings estén instaladas. En caso que no lo estén, primero se puede ejecutar

julia runFirst.jl

y posteriormente

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se puede cambiar la semilla pues los puntos son aleatorios. Como se envían, se resuelven con la misma semilla que los otros ejercicios para que haya continuidad en la tarea.

Las imágenes se guardan como pInterpolacioni-m.png y pMinimosCuadradosi-m.png donde i es 1 o 2 dependiendo de la función que se aproxima y m es el número de puntos que se consideran.