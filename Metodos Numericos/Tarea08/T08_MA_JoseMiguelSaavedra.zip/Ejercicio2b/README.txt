Ejercicio 2b de la tarea
Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora.

Se puede cambiar la semilla pues los puntos son aleatorios.

El archivo resultante se guarda como pi-m.txt donde i es 1 o 2 dependiendo de la función que se aproxima y m es el número de puntos que se consideran.