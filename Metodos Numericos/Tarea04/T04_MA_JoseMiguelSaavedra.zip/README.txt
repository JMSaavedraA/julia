Para correr simplemente ejecutar

julia main.jl

desde la linea de comando en la carpeta contenedora, o desde Visual Studio Code, igualmente con la carpeta contenedora

Se incluye Solvers.jl de la Tarea 03 pues algunas funciones de ahí que son reutilizadas.

Las funciones nuevas son las de Cholesky.jl, pero main.jl hace uso de ellos. Se puede cambiar el número de nodos para las diferencias finitas directo en el main